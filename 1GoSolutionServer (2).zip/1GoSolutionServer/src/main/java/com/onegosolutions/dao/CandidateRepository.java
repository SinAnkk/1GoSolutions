package com.onegosolutions.dao;

import org.springframework.data.repository.CrudRepository;

import com.onegosolutions.domain.Candidate_info;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

public interface CandidateRepository extends CrudRepository<Candidate_info, Long> {

}
