package com.onegosolutions.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.web.multipart.MultipartFile;

public class StorageService {
	
	private final Path rootLocation = Paths.get("E:\\1GoSolutions\\Resumes");
	 
	public String store(MultipartFile file) {
		try {
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
			return rootLocation.toString()+File.separator+file.getOriginalFilename();
		} catch (Exception e) {
			throw new RuntimeException("FAIL!");
		}
		
	}

}
